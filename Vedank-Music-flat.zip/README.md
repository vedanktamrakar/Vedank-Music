# Vedank Music Website

Premium white / vivid-blue identity with red accents and gold highlights, responsive layout, motion graphics, artist roster, DDEX register and Firebase-protected admin workspace.

## Deploy

This is a static website. The root directory is the site root. Import this repository into Vercel, or upload these files into the root of the existing `vedank-music` Vercel project. The public page is `/` and the private admin sign-in page is `/admin.html` (it is intentionally not linked in the public navigation and is marked `noindex`).

## Firebase setup (required for live roster editing)

1. In Firebase Console → Authentication → Sign-in method, enable **Email/Password**.
2. Create/verify the authorised account `vedankmusic@proton.me`; verify the email address. Do not create a public sign-up page.
3. Create Cloud Firestore database.
4. Paste the contents of `firestore.rules` into Firestore → Rules and publish.
5. Enable Firebase Storage, then paste `storage.rules` into Storage → Rules and publish.
6. Confirm the Firebase project has the matching web app configuration in `app.js` and `admin.js`.

## Security model

- The public page can read the single `siteContent/main` document.
- Only a signed-in user whose verified email exactly matches `vedankmusic@proton.me` can write that document or upload images.
- No public sign-up exists in the admin UI; the admin can sign in and request a password reset.
- Firebase Security Rules—not obscurity of `/admin.html`—enforce write access. Do not loosen the rules or place any service-account key in this folder.
- Storage accepts image types (including GIF) up to 10 MB. It does not allow arbitrary executable uploads.

## Notes

- Until Firestore contains a saved roster, the public page shows the two starter artist profiles defined in `app.js`.
- Admin form saves artist name, bio, genre, image, links, and optional custom icon/GIF to Firestore/Storage.
- The public DDEX panel reproduces the details supplied by the label owner. Confirm address spelling and official ID record before using it in compliance materials.
- `vedankmusic@proton.me` is used as the contact address on the public page.
